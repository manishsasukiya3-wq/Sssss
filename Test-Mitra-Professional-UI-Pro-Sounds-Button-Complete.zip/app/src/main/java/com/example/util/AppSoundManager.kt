package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.R

/** Centralized short UI sound effects with a single global mute switch. */
object AppSoundManager {
    private var soundPool: SoundPool? = null
    private var initialized = false
    private var clickId = 0
    private var actionId = 0
    private var successId = 0
    private var warningId = 0
    private var backId = 0
    private var loginId = 0
    private var submitId = 0
    private const val PREFS = "test_mitra_ui_sound"
    private const val KEY_MUTED = "muted"

    var isMuted by mutableStateOf(false)
        private set

    fun init(context: Context) {
        if (initialized) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        isMuted = prefs.getBoolean(KEY_MUTED, false)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        soundPool = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build()
        clickId = soundPool!!.load(context, R.raw.tm_click, 1)
        actionId = soundPool!!.load(context, R.raw.tm_action, 1)
        successId = soundPool!!.load(context, R.raw.tm_success, 1)
        warningId = soundPool!!.load(context, R.raw.tm_warning, 1)
        backId = soundPool!!.load(context, R.raw.tm_back, 1)
        loginId = soundPool!!.load(context, R.raw.tm_login, 1)
        submitId = soundPool!!.load(context, R.raw.tm_submit, 1)
        initialized = true
    }

    fun toggle(context: Context) {
        isMuted = !isMuted
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_MUTED, isMuted).apply()
        if (!isMuted) playAction()
    }

    fun setMuted(context: Context, muted: Boolean) {
        isMuted = muted
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_MUTED, muted).apply()
    }

    fun playClick() = play(clickId)
    fun playAction() = play(actionId)
    fun playSuccess() = play(successId)
    fun playWarning() = play(warningId)
    fun playBack() = play(backId)
    /** Pleasant welcome melody after a successful login. */
    fun playLoginSuccess() = play(loginId, 0.82f)
    /** Distinct completion melody after a test is successfully submitted/saved. */
    fun playSubmitSuccess() = play(submitId, 0.84f)

    private fun play(id: Int, volume: Float = 0.72f) {
        if (!initialized || isMuted || id == 0) return
        soundPool?.play(id, volume, volume, 1, 0, 1f)
    }

    fun release() {
        soundPool?.release()
        soundPool = null
        initialized = false
    }
}
